import { useState } from "react";
import { useNavigate, useSearchParams } from "react-router";
import Header from "../components/Header";
import { categoriesRepo, registerStore, loginLojista, sessionRepo } from "../lib/db";

type Mode = "client" | "lojista";
type View = "login" | "register" | "register-success" | "client-details";

export default function LoginPage() {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const initialMode: Mode = searchParams.get("mode") === "lojista" ? "lojista" : "client";
  const [mode, setMode] = useState<Mode>(initialMode);
  const [view, setView] = useState<View>("login");
  const [contact, setContact] = useState<"phone" | "whatsapp" | "email">("whatsapp");
  const [generatedId, setGeneratedId] = useState("");
  const [error, setError] = useState("");
  const categoryNames = categoriesRepo.getAllNames();

  const [form, setForm] = useState({ name: "", category: "", address: "", phone: "", whatsapp: "", username: "", password: "" });
  const [loginForm, setLoginForm] = useState({ user: "", password: "", storeId: "" });
  const [clientDetails, setClientDetails] = useState({ name: "", phone: "" });

  const onlyDigits = (v: string) => v.replace(/\D/g, "");
  const onlyLetters = (v: string) => v.replace(/[0-9]/g, "");

  async function handleRegisterSubmit() {
    setError("");
    if (!form.name || !form.category || !form.address || !form.phone || !form.username || !form.password) {
      setError("Preencha todos os campos obrigatórios.");
      return;
    }
    const store = await registerStore(form);
    setGeneratedId(store.loginId);
    setView("register-success");
  }

  async function handleLojistaLogin() {
    setError("");
    const store = await loginLojista(loginForm.user, loginForm.password, loginForm.storeId);
    if (!store) {
      setError("Usuário, senha ou ID inválidos — ou seu cadastro ainda está em análise.");
      return;
    }
    sessionRepo.set({ type: "lojista", name: store.username, storeId: store.id });
    navigate(`/dashboard/${store.id}`);
  }

  function handleGoogleClick() {
    setView("client-details");
  }

  function handleClientDetailsSubmit() {
    setError("");
    if (!clientDetails.name || !clientDetails.phone) {
      setError("Nome e telefone são obrigatórios.");
      return;
    }
    sessionRepo.set({ type: "client", name: clientDetails.name, phone: clientDetails.phone, email: `${clientDetails.name.toLowerCase().replace(/\s+/g, ".")}@gmail.com` });
    navigate("/");
  }

  if (view === "client-details") {
    return (
      <div className="min-h-screen flex flex-col bg-gray-50">
        <Header />
        <div className="flex-1 flex items-center justify-center px-4 py-16">
          <div className="bg-white rounded-3xl shadow-sm border border-gray-100 p-8 max-w-md w-full">
            <h2 className="text-2xl font-bold text-gray-900 mb-1" style={{ fontFamily: "var(--font-display)" }}>Quase lá</h2>
            <p className="text-sm text-gray-400 mb-6">Confirme seu nome e telefone para concluir o login com Google.</p>
            <div className="space-y-4">
              <div>
                <label className="text-xs font-medium text-gray-600 block mb-1">Nome</label>
                <input value={clientDetails.name} onChange={e => setClientDetails(p => ({ ...p, name: onlyLetters(e.target.value) }))}
                  placeholder="Seu nome" className="w-full border border-gray-200 rounded-xl px-4 py-3 text-sm outline-none focus:border-[#2F6B6B]" />
              </div>
              <div>
                <label className="text-xs font-medium text-gray-600 block mb-1">Telefone</label>
                <input value={clientDetails.phone} onChange={e => setClientDetails(p => ({ ...p, phone: onlyDigits(e.target.value) }))}
                  placeholder="(11) 99999-9999" className="w-full border border-gray-200 rounded-xl px-4 py-3 text-sm outline-none focus:border-[#2F6B6B]" />
              </div>
              {error && <p className="text-xs text-red-500">{error}</p>}
              <button onClick={handleClientDetailsSubmit} className="w-full py-3.5 rounded-xl text-white text-sm font-semibold" style={{ background: "#2F6B6B" }}>
                Concluir
              </button>
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (view === "register-success") {
    return (
      <div className="min-h-screen flex flex-col bg-gray-50">
        <Header />
        <div className="flex-1 flex items-center justify-center px-4 py-16">
          <div className="bg-white rounded-3xl shadow-sm border border-gray-100 p-10 max-w-md w-full text-center">
            <div className="w-16 h-16 rounded-full bg-[#EBF3F3] flex items-center justify-center mx-auto mb-5">
              <svg className="w-8 h-8 text-[#2F6B6B]" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4M7.835 4.697a3.42 3.42 0 001.946-.806 3.42 3.42 0 014.438 0 3.42 3.42 0 001.946.806 3.42 3.42 0 013.138 3.138 3.42 3.42 0 00.806 1.946 3.42 3.42 0 010 4.438 3.42 3.42 0 00-.806 1.946 3.42 3.42 0 01-3.138 3.138 3.42 3.42 0 00-1.946.806 3.42 3.42 0 01-4.438 0 3.42 3.42 0 00-1.946-.806 3.42 3.42 0 01-3.138-3.138 3.42 3.42 0 00-.806-1.946 3.42 3.42 0 010-4.438 3.42 3.42 0 00.806-1.946 3.42 3.42 0 013.138-3.138z" />
              </svg>
            </div>
            <h2 className="text-2xl font-bold text-gray-900 mb-2" style={{ fontFamily: "var(--font-display)" }}>Cadastro enviado!</h2>
            <p className="text-gray-500 text-sm mb-4">Seu cadastro está sendo analisado. Entraremos em contato em breve.</p>
            <div className="bg-[#EBF3F3] rounded-xl p-4 mb-6">
              <p className="text-xs text-gray-500 mb-1">Guarde seu ID de acesso — você vai precisar dele para entrar no seu painel:</p>
              <p className="text-2xl font-bold tracking-wider" style={{ color: "#2F6B6B", fontFamily: "var(--font-display)" }}>{generatedId}</p>
            </div>
            <p className="text-sm font-medium text-gray-700 mb-3">Como prefere ser contactado?</p>
            <div className="flex justify-center gap-3 mb-8">
              {(["phone", "whatsapp", "email"] as const).map(c => (
                <button key={c} onClick={() => setContact(c)}
                  className={`px-4 py-2 rounded-xl text-sm font-medium border transition-all ${contact === c ? "bg-[#2F6B6B] text-white border-[#2F6B6B]" : "border-gray-200 text-gray-600 hover:border-[#2F6B6B]"}`}>
                  {c === "phone" ? "📞 Telefone" : c === "whatsapp" ? "💬 WhatsApp" : "✉️ E-mail"}
                </button>
              ))}
            </div>
            <button onClick={() => navigate("/")} className="w-full py-3 rounded-xl text-white text-sm font-semibold" style={{ background: "#2F6B6B" }}>
              Voltar ao início
            </button>
          </div>
        </div>
      </div>
    );
  }

  if (view === "register") {
    return (
      <div className="min-h-screen flex flex-col bg-gray-50">
        <Header />
        <div className="flex-1 flex items-center justify-center px-4 py-12">
          <div className="bg-white rounded-3xl shadow-sm border border-gray-100 p-8 max-w-md w-full">
            <button onClick={() => setView("login")} className="text-sm text-gray-400 hover:text-gray-600 mb-6 flex items-center gap-1">
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" /></svg>
              Voltar
            </button>
            <h2 className="text-2xl font-bold text-gray-900 mb-1" style={{ fontFamily: "var(--font-display)" }}>Cadastrar loja</h2>
            <p className="text-sm text-gray-400 mb-7">Preencha os dados do seu estabelecimento.</p>
            <div className="space-y-4">
              <div>
                <label className="text-xs font-medium text-gray-600 block mb-1">Nome do estabelecimento</label>
                <input value={form.name} onChange={e => setForm(p => ({ ...p, name: e.target.value }))}
                  placeholder="Ex: Barbearia do João"
                  className="w-full border border-gray-200 rounded-xl px-4 py-3 text-sm outline-none focus:border-[#2F6B6B]" />
              </div>
              <div>
                <label className="text-xs font-medium text-gray-600 block mb-1">Categoria</label>
                <select value={form.category} onChange={e => setForm(p => ({ ...p, category: e.target.value }))}
                  className="w-full border border-gray-200 rounded-xl px-4 py-3 text-sm outline-none focus:border-[#2F6B6B] bg-white">
                  <option value="">Selecione uma categoria</option>
                  {categoryNames.map(c => <option key={c}>{c}</option>)}
                </select>
              </div>
              <div>
                <label className="text-xs font-medium text-gray-600 block mb-1">Endereço</label>
                <input value={form.address} onChange={e => setForm(p => ({ ...p, address: e.target.value }))}
                  placeholder="Av. Paulista, 1234 — São Paulo, SP"
                  className="w-full border border-gray-200 rounded-xl px-4 py-3 text-sm outline-none focus:border-[#2F6B6B]" />
              </div>
              <div>
                <label className="text-xs font-medium text-gray-600 block mb-1">Telefone</label>
                <input value={form.phone} onChange={e => setForm(p => ({ ...p, phone: onlyDigits(e.target.value) }))}
                  placeholder="11999999999"
                  className="w-full border border-gray-200 rounded-xl px-4 py-3 text-sm outline-none focus:border-[#2F6B6B]" />
              </div>
              <div>
                <label className="text-xs font-medium text-gray-600 block mb-1">WhatsApp (pode ser o mesmo número)</label>
                <input value={form.whatsapp} onChange={e => setForm(p => ({ ...p, whatsapp: onlyDigits(e.target.value) }))}
                  placeholder="11999999999"
                  className="w-full border border-gray-200 rounded-xl px-4 py-3 text-sm outline-none focus:border-[#2F6B6B]" />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-medium text-gray-600 block mb-1">Usuário (login)</label>
                  <input value={form.username} onChange={e => setForm(p => ({ ...p, username: e.target.value }))}
                    placeholder="ex: joao123"
                    className="w-full border border-gray-200 rounded-xl px-4 py-3 text-sm outline-none focus:border-[#2F6B6B]" />
                </div>
                <div>
                  <label className="text-xs font-medium text-gray-600 block mb-1">Senha</label>
                  <input type="password" value={form.password} onChange={e => setForm(p => ({ ...p, password: e.target.value }))}
                    placeholder="••••••••"
                    className="w-full border border-gray-200 rounded-xl px-4 py-3 text-sm outline-none focus:border-[#2F6B6B]" />
                </div>
              </div>
            </div>
            {error && <p className="text-xs text-red-500 mt-3">{error}</p>}
            <button onClick={handleRegisterSubmit}
              className="w-full mt-6 py-3.5 rounded-xl text-white text-sm font-semibold transition-colors"
              style={{ background: "#2F6B6B" }}>
              Enviar cadastro
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col bg-gray-50">
      <Header />
      <div className="flex-1 flex items-center justify-center px-4 py-16">
        <div className="bg-white rounded-3xl shadow-sm border border-gray-100 p-8 max-w-md w-full">
          <div className="flex bg-gray-100 rounded-xl p-1 mb-8">
            {(["client", "lojista"] as const).map(m => (
              <button key={m} onClick={() => { setMode(m); setError(""); }}
                className={`flex-1 py-2 rounded-lg text-sm font-medium transition-all ${mode === m ? "bg-white text-gray-900 shadow-sm" : "text-gray-500"}`}>
                {m === "client" ? "Entrar como Cliente" : "Entrar como Lojista"}
              </button>
            ))}
          </div>

          <h2 className="text-2xl font-bold text-gray-900 mb-1" style={{ fontFamily: "var(--font-display)" }}>
            {mode === "client" ? "Bem-vindo de volta" : "Área do Lojista"}
          </h2>
          <p className="text-sm text-gray-400 mb-7">
            {mode === "client" ? "Acesse sua conta para gerenciar seus agendamentos." : "Acesse seu painel de gerenciamento."}
          </p>

          {mode === "client" ? (
            <div className="space-y-4">
              <button onClick={handleGoogleClick}
                className="w-full flex items-center justify-center gap-3 py-3.5 rounded-xl border-2 border-gray-200 text-sm font-medium text-gray-700 hover:bg-gray-50 transition-colors">
                <svg viewBox="0 0 24 24" className="w-5 h-5" fill="currentColor">
                  <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" fill="#4285F4"/>
                  <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853"/>
                  <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" fill="#FBBC05"/>
                  <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335"/>
                </svg>
                Entrar com Google
              </button>
              <p className="text-xs text-gray-400 text-center px-4">
                O login de cliente é feito exclusivamente via Google — não existe cadastro tradicional com e-mail e senha nesta conta.
              </p>
            </div>
          ) : (
            <div className="space-y-4">
              {([
                { key: "user", label: "Usuário", placeholder: "Seu nome de usuário" },
                { key: "password", label: "Senha", placeholder: "••••••••", type: "password" },
                { key: "storeId", label: "ID da Loja", placeholder: "8 dígitos" },
              ] as { key: keyof typeof loginForm; label: string; placeholder: string; type?: string }[]).map(f => (
                <div key={f.key}>
                  <label className="text-xs font-medium text-gray-600 block mb-1">{f.label}</label>
                  <input type={f.type || "text"} placeholder={f.placeholder}
                    value={loginForm[f.key]}
                    onChange={e => setLoginForm(p => ({ ...p, [f.key]: f.key === "storeId" ? onlyDigits(e.target.value) : e.target.value }) as typeof loginForm)}
                    className="w-full border border-gray-200 rounded-xl px-4 py-3 text-sm outline-none focus:border-[#2F6B6B] transition-colors" />
                </div>
              ))}
              {error && <p className="text-xs text-red-500">{error}</p>}
              <button onClick={handleLojistaLogin} className="w-full py-3.5 rounded-xl text-white text-sm font-semibold" style={{ background: "#2F6B6B" }}>
                Acessar painel
              </button>
              <button onClick={() => setView("register")} className="w-full py-3 text-sm text-[#2F6B6B] font-medium hover:underline">
                Ainda não tem conta? Cadastre sua loja
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
