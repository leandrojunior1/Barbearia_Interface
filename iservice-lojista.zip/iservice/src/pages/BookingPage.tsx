import { useMemo, useState } from "react";
import { useNavigate, useParams } from "react-router";
import Header from "../components/Header";
import Footer from "../components/Footer";
import { storeRepo, bookingRepo, sessionRepo, buildWhatsAppLink, type Store, type Service, type Professional } from "../lib/db";

type Step = 1 | 2 | 3 | 4 | 5;
interface Selection { service: Service | null; professional: Professional | null; date: string | null; time: string | null; }

const WEEKDAY_LABEL = ["Dom", "Seg", "Ter", "Qua", "Qui", "Sex", "Sáb"];
const MONTH_LABEL = ["Jan", "Fev", "Mar", "Abr", "Mai", "Jun", "Jul", "Ago", "Set", "Out", "Nov", "Dez"];

function toISODate(d: Date) { return d.toISOString().slice(0, 10); }
function nextDays(n: number) { const out: Date[] = []; for (let i = 0; i < n; i++) { const d = new Date(); d.setDate(d.getDate() + i); out.push(d); } return out; }

function generateTimesForDay(store: Store, pro: Professional, date: string, durationMin: number): string[] {
  const [sh, sm] = pro.workStart.split(":").map(Number);
  const [eh, em] = pro.workEnd.split(":").map(Number);
  const [bh1, bm1] = pro.breakStart.split(":").map(Number);
  const [bh2, bm2] = pro.breakEnd.split(":").map(Number);
  const start = sh * 60 + sm, end = eh * 60 + em, breakStart = bh1 * 60 + bm1, breakEnd = bh2 * 60 + bm2;
  const slots: string[] = [];
  for (let m = start; m + durationMin <= end; m += 30) {
    if (m < breakEnd && m + durationMin > breakStart) continue;
    const time = `${String(Math.floor(m / 60)).padStart(2, "0")}:${String(m % 60).padStart(2, "0")}`;
    if (!bookingRepo.isSlotTaken(store.id, pro.id, date, time)) slots.push(time);
  }
  return slots;
}

function StepHeader({ step, label, done, active, summary }: { step: number; label: string; done: boolean; active: boolean; summary?: string }) {
  return (
    <div className={`flex items-center gap-4 p-4 rounded-xl transition-all ${active ? "bg-white shadow-sm border border-gray-100" : done ? "bg-gray-50" : "opacity-40"}`}>
      <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-semibold shrink-0 ${done ? "bg-[#2F6B6B] text-white" : active ? "border-2 border-[#2F6B6B] text-[#2F6B6B]" : "border-2 border-gray-200 text-gray-400"}`}>{done ? "✓" : step}</div>
      <div className="flex-1 min-w-0">
        <p className={`text-sm font-semibold ${active || done ? "text-gray-800" : "text-gray-400"}`}>{label}</p>
        {done && summary && <p className="text-xs text-[#2F6B6B] truncate">{summary}</p>}
      </div>
    </div>
  );
}

export default function BookingPage() {
  const { slug } = useParams();
  const navigate = useNavigate();
  const store = slug ? storeRepo.getById(slug) : undefined;

  const [step, setStep] = useState<Step>(1);
  const [sel, setSel] = useState<Selection>({ service: null, professional: null, date: null, time: null });
  const [success, setSuccess] = useState(false);
  const [thumb, setThumb] = useState(0);
  const [showTooltip, setShowTooltip] = useState<string | null>(null);
  const [needsLogin, setNeedsLogin] = useState(false);
  const [loginDetails, setLoginDetails] = useState({ name: "", phone: "" });
  const [loginError, setLoginError] = useState("");

  const session = sessionRepo.get();
  const days = useMemo(() => nextDays(14), []);

  if (!store) {
    return (
      <div className="min-h-screen flex flex-col">
        <Header />
        <div className="flex-1 flex items-center justify-center text-gray-400 text-sm py-24">Estabelecimento não encontrado.</div>
        <Footer />
      </div>
    );
  }
  const loadedStore: Store = store;

  const availableProfessionals = sel.service ? loadedStore.professionals.filter(p => p.serviceIds.includes(sel.service!.id)) : loadedStore.professionals;
  const availableTimes = sel.professional && sel.date && sel.service ? generateTimesForDay(loadedStore, sel.professional, sel.date, sel.service.duration) : [];

  function select<K extends keyof Selection>(key: K, value: Selection[K]) {
    setSel(prev => {
      const next = { ...prev, [key]: value } as Selection;
      if (key === "service") { next.professional = null; next.date = null; next.time = null; }
      if (key === "professional") { next.date = null; next.time = null; }
      if (key === "date") { next.time = null; }
      return next;
    });
    if (key === "time") {
      const current = sessionRepo.get();
      if (!current || current.type !== "client") { setNeedsLogin(true); setStep(5); return; }
      setStep(5);
    } else {
      setStep(s => Math.min((["service", "professional", "date", "time"].indexOf(key) + 2), 5) as Step);
    }
  }

  function handleInlineLogin() {
    setLoginError("");
    if (!loginDetails.name || !loginDetails.phone) { setLoginError("Nome e telefone são obrigatórios."); return; }
    sessionRepo.set({ type: "client", name: loginDetails.name, phone: loginDetails.phone });
    setNeedsLogin(false);
  }

  function confirmBooking() {
    const current = sessionRepo.get();
    if (!current || !sel.service || !sel.professional || !sel.date || !sel.time) return;
    bookingRepo.save({
      id: crypto.randomUUID(), storeId: loadedStore.id, serviceId: sel.service.id, professionalId: sel.professional.id,
      date: sel.date, time: sel.time, clientName: current.name, clientPhone: current.phone ?? "",
      status: "confirmado", price: sel.service.price, createdAt: new Date().toISOString(),
    });
    const message = `Olá! Confirmando meu agendamento em ${loadedStore.name}:\nServiço: ${sel.service.name}\nProfissional: ${sel.professional.name}\nData: ${sel.date}\nHorário: ${sel.time}`;
    window.open(buildWhatsAppLink(loadedStore.whatsapp, message), "_blank");
    setSuccess(true);
  }

  const dayLabel = (d: Date) => `${WEEKDAY_LABEL[d.getDay()]}, ${d.getDate()} ${MONTH_LABEL[d.getMonth()]}`;
  const dayAvailable = (d: Date) => {
    if (!sel.professional) return false;
    const iso = toISODate(d);
    if (store.establishment.holidays.includes(iso)) return false;
    if (!sel.professional.workDays.includes(d.getDay())) return false;
    return generateTimesForDay(store, sel.professional, iso, sel.service?.duration ?? 30).length > 0;
  };

  if (success) {
    return (
      <div className="min-h-screen flex flex-col">
        <Header />
        <div className="flex-1 flex flex-col items-center justify-center px-4 py-20 text-center">
          <div className="w-20 h-20 rounded-full bg-[#EBF3F3] flex items-center justify-center mb-6">
            <svg className="w-10 h-10 text-[#2F6B6B]" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" /></svg>
          </div>
          <h2 className="text-3xl font-bold text-gray-900 mb-3" style={{ fontFamily: "var(--font-display)" }}>Seu agendamento foi confirmado com sucesso</h2>
          <p className="text-sm text-gray-400 mb-8">Abrimos o WhatsApp da loja com os detalhes preenchidos.</p>
          <div className="bg-gray-50 rounded-2xl p-6 text-left max-w-sm w-full space-y-3 mb-8">
            <div className="flex justify-between text-sm"><span className="text-gray-500">Serviço</span><span className="font-medium">{sel.service?.name}</span></div>
            <div className="flex justify-between text-sm"><span className="text-gray-500">Profissional</span><span className="font-medium">{sel.professional?.name}</span></div>
            <div className="flex justify-between text-sm"><span className="text-gray-500">Data</span><span className="font-medium">{sel.date}</span></div>
            <div className="flex justify-between text-sm"><span className="text-gray-500">Horário</span><span className="font-medium">{sel.time}</span></div>
          </div>
          <button onClick={() => navigate("/")} className="text-sm text-[#2F6B6B] font-medium hover:underline">Voltar ao início</button>
        </div>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col bg-gray-50">
      <Header loggedIn={!!session} userName={session?.name} />
      <div className="bg-white border-b border-gray-100">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 py-6">
          <div className="flex items-start gap-2 mb-3">
            <div><h1 className="text-2xl font-bold text-gray-900" style={{ fontFamily: "var(--font-display)" }}>{store.name}</h1><p className="text-sm text-gray-500">{store.category} · {store.address}</p></div>
          </div>
          {store.gallery.length > 0 && (
            <>
              <div className="rounded-2xl overflow-hidden mb-2"><img src={store.gallery[thumb]} alt="Estabelecimento" className="w-full h-56 sm:h-80 object-cover" /></div>
              <div className="flex gap-2 overflow-x-auto">
                {store.gallery.map((g, i) => <button key={i} onClick={() => setThumb(i)} className={`shrink-0 rounded-xl overflow-hidden border-2 transition-all ${thumb === i ? "border-[#2F6B6B]" : "border-transparent"}`}><img src={g} alt="" className="w-20 h-14 object-cover" /></button>)}
              </div>
            </>
          )}
        </div>
        <div className="max-w-4xl mx-auto px-4 sm:px-6 pb-6">
          <div className="flex flex-wrap gap-4">
            {store.amenities.map(a => <div key={a} className="flex items-center gap-1.5 text-sm text-gray-600"><span>✓</span> {a}</div>)}
            <div className="relative flex items-center gap-1.5 text-sm text-gray-600" onMouseEnter={() => setShowTooltip("outro")} onMouseLeave={() => setShowTooltip(null)}>
              <span>✱</span> Outro
              {showTooltip === "outro" && <div className="absolute bottom-full left-0 mb-2 bg-gray-900 text-white text-xs px-3 py-2 rounded-xl whitespace-nowrap z-10">Espaço privativo disponível mediante agendamento</div>}
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-4 sm:px-6 py-8 w-full">
        <h2 className="text-xl font-bold text-gray-900 mb-6" style={{ fontFamily: "var(--font-display)" }}>Faça seu agendamento</h2>
        <div className="space-y-3">
          <div>
            <StepHeader step={1} label="Serviço" done={step > 1} active={step === 1} summary={sel.service ? `${sel.service.name} — R$ ${sel.service.price.toFixed(2)}` : undefined} />
            {step === 1 && (
              <div className="mt-2 grid grid-cols-1 sm:grid-cols-2 gap-3">
                {store.services.length === 0 && <p className="text-sm text-gray-400 col-span-2">Esta loja ainda não cadastrou serviços.</p>}
                {store.services.map(s => (
                  <button key={s.id} onClick={() => select("service", s)} className={`text-left p-4 rounded-xl border transition-all ${sel.service?.id === s.id ? "border-[#2F6B6B] bg-[#EBF3F3]" : "bg-white border-gray-100 hover:border-[#2F6B6B]/40"}`}>
                    <p className="font-medium text-gray-800 text-sm">{s.name}</p>
                    <div className="flex items-center gap-3 mt-1"><span className="text-xs text-gray-400">{s.duration} min</span><span className="text-sm font-semibold text-[#2F6B6B]">R$ {s.price.toFixed(2)}</span></div>
                  </button>
                ))}
              </div>
            )}
          </div>
          <div>
            <StepHeader step={2} label="Profissional" done={step > 2} active={step === 2} summary={sel.professional?.name} />
            {step === 2 && (
              <div className="mt-2 grid grid-cols-1 sm:grid-cols-3 gap-3">
                {availableProfessionals.length === 0 && <p className="text-sm text-gray-400 col-span-3">Nenhum profissional realiza esse serviço ainda.</p>}
                {availableProfessionals.map(p => (
                  <button key={p.id} onClick={() => select("professional", p)} className={`p-4 rounded-xl border text-center transition-all ${sel.professional?.id === p.id ? "border-[#2F6B6B] bg-[#EBF3F3]" : "bg-white border-gray-100 hover:border-[#2F6B6B]/40"}`}>
                    <div className="w-16 h-16 rounded-full overflow-hidden mx-auto mb-2 ring-2 ring-transparent hover:ring-[#2F6B6B] transition-all cursor-zoom-in"><img src={p.photo} alt={p.name} className="w-full h-full object-cover" /></div>
                    <p className="font-medium text-gray-800 text-sm">{p.name}</p><p className="text-xs text-gray-400 mt-0.5">{p.role}</p>
                  </button>
                ))}
              </div>
            )}
          </div>
          <div>
            <StepHeader step={3} label="Dia" done={step > 3} active={step === 3} summary={sel.date ? dayLabel(new Date(sel.date + "T00:00:00")) : undefined} />
            {step === 3 && (
              <div className="mt-2 bg-white rounded-xl border border-gray-100 p-4">
                <div className="flex gap-2 overflow-x-auto pb-1">
                  {days.map(d => {
                    const iso = toISODate(d);
                    const available = dayAvailable(d);
                    return (
                      <button key={iso} onClick={() => available && select("date", iso)} disabled={!available}
                        className={`shrink-0 px-4 py-3 rounded-xl text-sm font-medium transition-all border ${!available ? "opacity-35 grayscale cursor-not-allowed bg-gray-50 text-gray-400 border-gray-100" : sel.date === iso ? "bg-[#2F6B6B] text-white border-[#2F6B6B]" : "bg-white border-gray-200 text-gray-700 hover:border-[#2F6B6B]"}`}>
                        {dayLabel(d)}
                      </button>
                    );
                  })}
                </div>
              </div>
            )}
          </div>
          <div>
            <StepHeader step={4} label="Horário" done={step > 4} active={step === 4} summary={sel.time || undefined} />
            {step === 4 && (
              <div className="mt-2 bg-white rounded-xl border border-gray-100 p-4">
                {availableTimes.length === 0 ? <p className="text-sm text-gray-400">Nenhum horário disponível — volte e escolha outro dia.</p> : (
                  <div className="flex flex-wrap gap-2">
                    {availableTimes.map(t => <button key={t} onClick={() => select("time", t)} className={`px-4 py-2 rounded-xl text-sm font-medium border transition-all ${sel.time === t ? "bg-[#2F6B6B] text-white border-[#2F6B6B]" : "bg-white border-gray-200 text-gray-700 hover:border-[#2F6B6B]"}`}>{t}</button>)}
                  </div>
                )}
              </div>
            )}
          </div>
          <div>
            <StepHeader step={5} label="Confirmação" done={false} active={step === 5} />
            {step === 5 && needsLogin && (
              <div className="mt-2 bg-white rounded-xl border border-gray-100 p-6">
                <p className="text-sm text-gray-600 mb-4">Você precisa estar logado para concluir o agendamento. Sua seleção foi salva.</p>
                <div className="space-y-3 max-w-sm">
                  <input placeholder="Nome" value={loginDetails.name} onChange={e => setLoginDetails(p => ({ ...p, name: e.target.value }))} className="w-full border border-gray-200 rounded-xl px-4 py-3 text-sm" />
                  <input placeholder="Telefone" value={loginDetails.phone} onChange={e => setLoginDetails(p => ({ ...p, phone: e.target.value.replace(/\D/g, "") }))} className="w-full border border-gray-200 rounded-xl px-4 py-3 text-sm" />
                  {loginError && <p className="text-xs text-red-500">{loginError}</p>}
                  <button onClick={handleInlineLogin} className="w-full py-3 rounded-xl text-white text-sm font-semibold" style={{ background: "#2F6B6B" }}>Entrar com Google (simulado) e continuar</button>
                </div>
              </div>
            )}
            {step === 5 && !needsLogin && (
              <div className="mt-2 bg-white rounded-xl border border-gray-100 p-6">
                <h3 className="font-semibold text-gray-800 mb-4">Resumo do agendamento</h3>
                <div className="space-y-3 mb-6">
                  {[{ label: "Serviço", value: `${sel.service?.name} — R$ ${sel.service?.price.toFixed(2)}` }, { label: "Duração", value: `${sel.service?.duration} min` }, { label: "Profissional", value: sel.professional?.name }, { label: "Data", value: sel.date }, { label: "Horário", value: sel.time }].map(row => (
                    <div key={row.label} className="flex justify-between items-center py-2 border-b border-gray-50 last:border-0"><span className="text-sm text-gray-500">{row.label}</span><span className="text-sm font-medium text-gray-800">{row.value}</span></div>
                  ))}
                </div>
                <div className="flex gap-3">
                  <button onClick={() => setStep(1)} className="flex-1 py-3 rounded-xl border border-gray-200 text-sm font-medium text-gray-600 hover:bg-gray-50 transition-colors">Editar</button>
                  <button onClick={confirmBooking} className="flex-1 py-3 rounded-xl text-white text-sm font-semibold transition-colors" style={{ background: "#2F6B6B" }}>Confirmar agendamento</button>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      <button onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })} className="fixed bottom-6 right-6 w-11 h-11 rounded-full bg-[#2F6B6B] text-white shadow-lg flex items-center justify-center hover:bg-[#234F4F] transition-colors z-40">
        <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 10l7-7m0 0l7 7m-7-7v18" /></svg>
      </button>
      <Footer />
    </div>
  );
}
